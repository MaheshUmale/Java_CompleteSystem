package com.upstox.sanity;

public class DataToken {
    public static final String accessToken = "";
    public static final String sandboxToken = "";
    public static final String algoName = "name";
}
