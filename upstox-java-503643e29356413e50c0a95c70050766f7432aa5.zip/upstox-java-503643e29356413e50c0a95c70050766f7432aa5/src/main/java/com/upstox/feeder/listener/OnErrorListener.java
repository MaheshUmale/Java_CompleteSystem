package com.upstox.feeder.listener;

public interface OnErrorListener {
    void onError(Throwable error);
}
