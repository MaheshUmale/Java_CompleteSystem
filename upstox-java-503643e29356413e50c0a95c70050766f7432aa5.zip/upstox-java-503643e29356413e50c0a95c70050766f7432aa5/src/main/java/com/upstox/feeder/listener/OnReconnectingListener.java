package com.upstox.feeder.listener;

public interface OnReconnectingListener {
    void onReconnecting(String message);
}
