package com.upstox.feeder.constants;

public enum Mode {
    LTPC, FULL, OPTION_GREEKS, FULL_D30
}
