package com.upstox.feeder.listener;

public interface OnOpenListener {
    void onOpen();
}
