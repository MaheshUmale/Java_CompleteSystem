package com.upstox.feeder.listener;

public interface OnAutoReconnectStoppedListener {
    void onHault(String message);
}
