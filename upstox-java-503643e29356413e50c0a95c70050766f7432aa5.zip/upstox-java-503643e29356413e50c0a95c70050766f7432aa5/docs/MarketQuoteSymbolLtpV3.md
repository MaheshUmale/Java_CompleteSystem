# MarketQuoteSymbolLtpV3

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lastPrice** | **Double** |  |  [optional]
**instrumentToken** | **String** |  |  [optional]
**ltq** | **Long** |  |  [optional]
**volume** | **Long** |  |  [optional]
**cp** | **Double** |  |  [optional]
