# CancelOrderData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderId** | **String** | Reference order ID |  [optional]
