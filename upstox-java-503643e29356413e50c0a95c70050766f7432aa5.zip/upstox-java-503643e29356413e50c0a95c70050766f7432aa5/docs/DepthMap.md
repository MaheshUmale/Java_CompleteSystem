# DepthMap

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**buy** | [**List&lt;Depth&gt;**](Depth.md) | Bids |  [optional]
**sell** | [**List&lt;Depth&gt;**](Depth.md) | Asks |  [optional]
