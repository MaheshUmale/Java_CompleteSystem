# ProfitAndLossOtherChargesTaxes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transaction** | **Float** | transaction charges |  [optional]
**clearing** | **Float** | clearing charges |  [optional]
**others** | **Float** | others charges |  [optional]
**sebiTurnover** | **Float** | SEBI turnover |  [optional]
**dematTransaction** | **Float** | demat transaction charges |  [optional]
