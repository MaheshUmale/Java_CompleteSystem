# MultiOrderData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**correlationId** | **String** | A unique identifier for tracking individual orders within the batch |  [optional]
**orderId** | **String** | An order ID for the order request placed |  [optional]
