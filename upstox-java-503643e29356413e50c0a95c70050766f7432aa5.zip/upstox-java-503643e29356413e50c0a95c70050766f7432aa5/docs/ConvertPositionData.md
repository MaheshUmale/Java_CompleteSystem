# ConvertPositionData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** | Status message for convert position request |  [optional]
