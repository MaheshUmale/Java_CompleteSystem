# OrderMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**latency** | **Long** |  |  [optional]
