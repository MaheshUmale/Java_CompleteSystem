# MarketQuoteOHLC

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ohlc** | [**Ohlc**](Ohlc.md) |  |  [optional]
**lastPrice** | **Float** | The last traded price of symbol |  [optional]
**instrumentToken** | **String** |  |  [optional]
