# CancelOrExitMultiOrderData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderIds** | **List&lt;String&gt;** | Reference order IDs |  [optional]
