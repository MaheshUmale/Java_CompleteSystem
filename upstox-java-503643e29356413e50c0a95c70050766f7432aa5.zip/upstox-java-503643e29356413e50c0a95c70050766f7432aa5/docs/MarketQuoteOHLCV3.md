# MarketQuoteOHLCV3

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lastPrice** | **Double** | The last traded price of symbol |  [optional]
**instrumentToken** | **String** |  |  [optional]
**prevOhlc** | [**OhlcV3**](OhlcV3.md) |  |  [optional]
**liveOhlc** | [**OhlcV3**](OhlcV3.md) |  |  [optional]
