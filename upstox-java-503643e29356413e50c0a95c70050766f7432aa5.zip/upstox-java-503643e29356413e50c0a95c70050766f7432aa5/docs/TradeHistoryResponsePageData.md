# TradeHistoryResponsePageData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pageNumber** | **Integer** |  |  [optional]
**pageSize** | **Integer** |  |  [optional]
**totalRecords** | **Integer** |  |  [optional]
**totalPages** | **Integer** |  |  [optional]
