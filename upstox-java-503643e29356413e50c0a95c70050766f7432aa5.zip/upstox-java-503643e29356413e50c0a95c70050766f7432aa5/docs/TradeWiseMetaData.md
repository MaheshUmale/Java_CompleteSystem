# TradeWiseMetaData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tradesCount** | **Integer** | Total count of trades in the trade wise P and L report |  [optional]
**pageSizeLimit** | **Integer** | Maximum number of trades in a page of the trade wise P and L report API |  [optional]
