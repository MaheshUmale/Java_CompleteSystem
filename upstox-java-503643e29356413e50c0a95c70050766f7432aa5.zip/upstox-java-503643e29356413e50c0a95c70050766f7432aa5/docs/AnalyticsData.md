# AnalyticsData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**vega** | **Double** |  |  [optional]
**theta** | **Double** |  |  [optional]
**gamma** | **Double** |  |  [optional]
**delta** | **Double** |  |  [optional]
**iv** | **Double** |  |  [optional]
**pop** | **Double** |  |  [optional]
