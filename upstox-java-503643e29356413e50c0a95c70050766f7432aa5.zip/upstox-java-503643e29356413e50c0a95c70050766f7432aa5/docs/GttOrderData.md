# GttOrderData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**gttOrderIds** | **List&lt;String&gt;** | Order ID for the placed GTT order |  [optional]
