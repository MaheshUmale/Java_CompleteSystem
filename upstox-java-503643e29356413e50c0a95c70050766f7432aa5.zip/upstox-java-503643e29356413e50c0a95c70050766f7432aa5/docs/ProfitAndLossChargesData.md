# ProfitAndLossChargesData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **Float** |   Total charges for the user |  [optional]
**brokerage** | **Float** | Brokerage charges for the order |  [optional]
**taxes** | [**ProfitAndLossChargesTaxes**](ProfitAndLossChargesTaxes.md) |  |  [optional]
**charges** | [**ProfitAndLossOtherChargesTaxes**](ProfitAndLossOtherChargesTaxes.md) |  |  [optional]
