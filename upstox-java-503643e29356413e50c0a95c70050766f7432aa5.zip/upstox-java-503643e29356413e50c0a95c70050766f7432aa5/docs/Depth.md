# Depth

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quantity** | **Integer** | quantity |  [optional]
**price** | **Double** | price |  [optional]
**orders** | **Integer** | orders |  [optional]
