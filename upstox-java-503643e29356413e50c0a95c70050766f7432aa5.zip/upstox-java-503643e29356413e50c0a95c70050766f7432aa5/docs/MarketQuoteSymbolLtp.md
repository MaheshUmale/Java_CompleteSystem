# MarketQuoteSymbolLtp

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lastPrice** | **Double** | The last traded price of symbol |  [optional]
**instrumentToken** | **String** |  |  [optional]
