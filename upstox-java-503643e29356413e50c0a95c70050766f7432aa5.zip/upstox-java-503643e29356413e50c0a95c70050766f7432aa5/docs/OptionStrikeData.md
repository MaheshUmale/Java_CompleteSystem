# OptionStrikeData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**expiry** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**pcr** | **Double** |  |  [optional]
**strikePrice** | **Double** |  |  [optional]
**underlyingKey** | **String** |  |  [optional]
**underlyingSpotPrice** | **Double** |  |  [optional]
**callOptions** | [**PutCallOptionChainData**](PutCallOptionChainData.md) |  |  [optional]
**putOptions** | [**PutCallOptionChainData**](PutCallOptionChainData.md) |  |  [optional]
