# BrokerageWrapperData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**charges** | [**BrokerageData**](BrokerageData.md) |  |  [optional]
