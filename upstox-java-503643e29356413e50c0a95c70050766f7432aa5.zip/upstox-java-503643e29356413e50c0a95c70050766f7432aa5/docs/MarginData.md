# MarginData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**margins** | [**List&lt;Margin&gt;**](Margin.md) | Response data for instrument margin details |  [optional]
**requiredMargin** | **Double** | Total margin required to execute the orders |  [optional]
**finalMargin** | **Double** | Total margin after margin benefit |  [optional]
