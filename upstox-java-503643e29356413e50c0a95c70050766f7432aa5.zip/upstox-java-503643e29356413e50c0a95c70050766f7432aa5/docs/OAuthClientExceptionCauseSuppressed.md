# OAuthClientExceptionCauseSuppressed

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stackTrace** | [**List&lt;OAuthClientExceptionCauseStackTrace&gt;**](OAuthClientExceptionCauseStackTrace.md) |  |  [optional]
**message** | **String** |  |  [optional]
**localizedMessage** | **String** |  |  [optional]
