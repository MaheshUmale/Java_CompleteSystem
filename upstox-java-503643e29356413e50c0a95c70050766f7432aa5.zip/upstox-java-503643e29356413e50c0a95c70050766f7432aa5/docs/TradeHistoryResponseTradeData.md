# TradeHistoryResponseTradeData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exchange** | **String** |  |  [optional]
**segment** | **String** |  |  [optional]
**optionType** | **String** |  |  [optional]
**quantity** | **Integer** |  |  [optional]
**amount** | **Float** |  |  [optional]
**tradeId** | **String** |  |  [optional]
**tradeDate** | **String** |  |  [optional]
**transactionType** | **String** |  |  [optional]
**scripName** | **String** |  |  [optional]
**strikePrice** | **String** |  |  [optional]
**expiry** | **String** |  |  [optional]
**price** | **Float** |  |  [optional]
**isin** | **String** |  |  [optional]
**symbol** | **String** |  |  [optional]
**instrumentToken** | **String** |  |  [optional]
