# ProfitAndLossMetaData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pageNumber** | **Integer** | pageNumber for pagination |  [optional]
**pageSize** | **Integer** | Page size |  [optional]
