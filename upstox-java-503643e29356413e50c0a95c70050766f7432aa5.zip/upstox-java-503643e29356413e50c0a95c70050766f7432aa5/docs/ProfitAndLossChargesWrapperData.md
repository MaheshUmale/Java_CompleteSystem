# ProfitAndLossChargesWrapperData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**chargesBreakdown** | [**ProfitAndLossChargesData**](ProfitAndLossChargesData.md) |  |  [optional]
