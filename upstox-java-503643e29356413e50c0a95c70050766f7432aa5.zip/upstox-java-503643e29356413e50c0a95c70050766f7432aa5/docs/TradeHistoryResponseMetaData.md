# TradeHistoryResponseMetaData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**page** | [**TradeHistoryResponsePageData**](TradeHistoryResponsePageData.md) |  |  [optional]
