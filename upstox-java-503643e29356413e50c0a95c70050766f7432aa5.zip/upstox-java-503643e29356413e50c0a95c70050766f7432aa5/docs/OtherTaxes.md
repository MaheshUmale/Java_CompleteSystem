# OtherTaxes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transaction** | **Float** | Transaction charges |  [optional]
**clearing** | **Float** | Clearing charges |  [optional]
**sebiTurnover** | **Float** | SEBI turnover charges |  [optional]
