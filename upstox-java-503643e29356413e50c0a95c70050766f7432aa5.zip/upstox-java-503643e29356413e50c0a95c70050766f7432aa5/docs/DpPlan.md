# DpPlan

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name |  [optional]
**minExpense** | **Float** | Minimum expense charges |  [optional]
