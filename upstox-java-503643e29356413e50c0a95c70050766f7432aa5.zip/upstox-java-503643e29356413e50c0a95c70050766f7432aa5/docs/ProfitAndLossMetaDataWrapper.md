# ProfitAndLossMetaDataWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**page** | [**ProfitAndLossMetaData**](ProfitAndLossMetaData.md) |  |  [optional]
