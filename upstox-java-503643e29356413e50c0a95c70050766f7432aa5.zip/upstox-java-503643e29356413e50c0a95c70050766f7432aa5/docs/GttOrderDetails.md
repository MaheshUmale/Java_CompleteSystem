# GttOrderDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  |  [optional]
**exchange** | **String** |  |  [optional]
**quantity** | **Integer** |  |  [optional]
**product** | **String** |  |  [optional]
**rules** | [**List&lt;Rule&gt;**](Rule.md) |  |  [optional]
**tradingSymbol** | **String** |  |  [optional]
**instrumentToken** | **String** |  |  [optional]
**gttOrderId** | **String** |  |  [optional]
**expiresAt** | **Long** |  |  [optional]
**createdAt** | **Long** |  |  [optional]
