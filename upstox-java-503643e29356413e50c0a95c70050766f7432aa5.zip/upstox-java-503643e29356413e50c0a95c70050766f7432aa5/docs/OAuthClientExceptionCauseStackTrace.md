# OAuthClientExceptionCauseStackTrace

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**classLoaderName** | **String** |  |  [optional]
**moduleName** | **String** |  |  [optional]
**moduleVersion** | **String** |  |  [optional]
**methodName** | **String** |  |  [optional]
**fileName** | **String** |  |  [optional]
**lineNumber** | **Integer** |  |  [optional]
**className** | **String** |  |  [optional]
**nativeMethod** | **Boolean** |  |  [optional]
