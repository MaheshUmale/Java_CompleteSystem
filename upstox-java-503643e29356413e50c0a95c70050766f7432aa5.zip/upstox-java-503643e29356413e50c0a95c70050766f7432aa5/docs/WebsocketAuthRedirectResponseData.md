# WebsocketAuthRedirectResponseData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authorizedRedirectUri** | **String** |  |  [optional]
