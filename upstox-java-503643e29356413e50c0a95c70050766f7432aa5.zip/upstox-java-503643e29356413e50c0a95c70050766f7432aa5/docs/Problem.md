# Problem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errorCode** | **String** | Unique code for the error state |  [optional]
**message** | **String** | Verbose message for the error state |  [optional]
**propertyPath** | **String** | Path to property failing validation |  [optional]
**invalidValue** | **Object** | Invalid value for the property failing validation |  [optional]
**errorCode** | **String** |  |  [optional]
**propertyPath** | **String** |  |  [optional]
**invalidValue** | **Object** |  |  [optional]
