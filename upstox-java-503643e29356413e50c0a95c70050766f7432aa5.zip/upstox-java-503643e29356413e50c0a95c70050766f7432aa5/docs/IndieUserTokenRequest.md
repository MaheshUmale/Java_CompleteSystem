# IndieUserTokenRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clientSecret** | **String** | OAuth client secret that is a private secret known only to app and authorization server |  [optional]
