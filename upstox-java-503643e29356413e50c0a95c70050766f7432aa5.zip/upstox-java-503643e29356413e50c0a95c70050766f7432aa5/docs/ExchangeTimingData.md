# ExchangeTimingData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exchange** | **String** |  |  [optional]
**startTime** | **Long** |  |  [optional]
**endTime** | **Long** |  |  [optional]
