# OAuthClientException

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cause** | [**OAuthClientExceptionCause**](OAuthClientExceptionCause.md) |  |  [optional]
**stackTrace** | [**List&lt;OAuthClientExceptionCauseStackTrace&gt;**](OAuthClientExceptionCauseStackTrace.md) |  |  [optional]
**message** | **String** |  |  [optional]
**suppressed** | [**List&lt;OAuthClientExceptionCauseSuppressed&gt;**](OAuthClientExceptionCauseSuppressed.md) |  |  [optional]
**localizedMessage** | **String** |  |  [optional]
