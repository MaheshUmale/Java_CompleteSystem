# OAuthClientExceptionCause

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stackTrace** | [**List&lt;OAuthClientExceptionCauseStackTrace&gt;**](OAuthClientExceptionCauseStackTrace.md) |  |  [optional]
**message** | **String** |  |  [optional]
**suppressed** | [**List&lt;OAuthClientExceptionCauseSuppressed&gt;**](OAuthClientExceptionCauseSuppressed.md) |  |  [optional]
**localizedMessage** | **String** |  |  [optional]
