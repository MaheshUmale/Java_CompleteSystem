# PlaceOrderData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderId** | **String** | An order ID for the order request placed |  [optional]
