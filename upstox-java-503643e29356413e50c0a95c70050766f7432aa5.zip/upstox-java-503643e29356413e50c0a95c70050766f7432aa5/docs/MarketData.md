# MarketData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ltp** | **Double** |  |  [optional]
**volume** | **Long** |  |  [optional]
**oi** | **Double** |  |  [optional]
**closePrice** | **Double** |  |  [optional]
**bidPrice** | **Double** |  |  [optional]
**bidQty** | **Integer** |  |  [optional]
**askPrice** | **Double** |  |  [optional]
**askQty** | **Integer** |  |  [optional]
**prevOi** | **Double** |  |  [optional]
