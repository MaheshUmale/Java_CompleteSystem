# MarketStatusData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exchange** | **String** |  |  [optional]
**status** | **String** |  |  [optional]
**lastUpdated** | **Long** |  |  [optional]
