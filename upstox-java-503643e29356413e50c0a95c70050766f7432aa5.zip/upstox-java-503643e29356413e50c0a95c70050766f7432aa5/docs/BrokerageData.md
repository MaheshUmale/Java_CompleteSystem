# BrokerageData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **Float** | Total charges for the order |  [optional]
**brokerage** | **Float** | Brokerage charges for the order |  [optional]
**taxes** | [**BrokerageTaxes**](BrokerageTaxes.md) |  |  [optional]
**otherTaxes** | [**OtherTaxes**](OtherTaxes.md) |  |  [optional]
**dpPlan** | [**DpPlan**](DpPlan.md) |  |  [optional]
