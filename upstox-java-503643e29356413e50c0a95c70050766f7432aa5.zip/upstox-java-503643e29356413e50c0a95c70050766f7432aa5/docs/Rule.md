# Rule

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**strategy** | **String** |  |  [optional]
**status** | **String** |  |  [optional]
**triggerType** | **String** |  |  [optional]
**triggerPrice** | **Double** |  |  [optional]
**transactionType** | **String** |  |  [optional]
**orderId** | **String** |  |  [optional]
