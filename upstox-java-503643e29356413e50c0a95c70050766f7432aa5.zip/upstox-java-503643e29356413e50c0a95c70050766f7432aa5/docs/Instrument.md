# Instrument

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instrumentKey** | **String** | Instrument Key of the Instrument | 
**quantity** | **Integer** | Quantity of the instrument to buy or sell for margin calculation | 
**product** | **String** | Product with which the order is to be placed | 
**transactionType** | **String** | Indicates whether its a BUY or SELL order | 
**price** | **Double** | price |  [optional]
