# MultiOrderV3Data

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderIds** | **List&lt;String&gt;** |  |  [optional]
