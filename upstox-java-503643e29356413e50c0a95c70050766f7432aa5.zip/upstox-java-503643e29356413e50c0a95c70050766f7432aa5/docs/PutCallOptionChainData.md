# PutCallOptionChainData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instrumentKey** | **String** |  |  [optional]
**marketData** | [**MarketData**](MarketData.md) |  |  [optional]
**optionGreeks** | [**AnalyticsData**](AnalyticsData.md) |  |  [optional]
