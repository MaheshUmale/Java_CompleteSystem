# MarginRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instruments** | [**List&lt;Instrument&gt;**](Instrument.md) | instruments | 
