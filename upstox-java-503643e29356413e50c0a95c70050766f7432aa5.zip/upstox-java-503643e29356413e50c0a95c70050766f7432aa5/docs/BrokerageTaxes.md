# BrokerageTaxes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**gst** | **Float** | GST charges |  [optional]
**stt** | **Float** | STT charges |  [optional]
**stampDuty** | **Float** | Stamp duty charges |  [optional]
