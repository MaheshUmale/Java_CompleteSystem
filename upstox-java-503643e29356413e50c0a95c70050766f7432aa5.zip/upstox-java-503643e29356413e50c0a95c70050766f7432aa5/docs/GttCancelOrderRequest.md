# GttCancelOrderRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**gttOrderId** | **String** | Unique identifier of the GTT order to be cancelled | 
