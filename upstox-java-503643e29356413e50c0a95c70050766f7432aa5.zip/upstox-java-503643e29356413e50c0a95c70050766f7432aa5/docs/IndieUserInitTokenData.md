# IndieUserInitTokenData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authorizationExpiry** | **String** | authorize token expiry |  [optional]
**notifierUrl** | **String** | notifier webhook url |  [optional]
