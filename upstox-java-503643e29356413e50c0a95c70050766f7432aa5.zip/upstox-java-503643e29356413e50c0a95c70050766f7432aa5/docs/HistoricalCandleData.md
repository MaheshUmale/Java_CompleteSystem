# HistoricalCandleData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**candles** | [**List&lt;List&lt;Object&gt;&gt;**](List.md) |  |  [optional]
